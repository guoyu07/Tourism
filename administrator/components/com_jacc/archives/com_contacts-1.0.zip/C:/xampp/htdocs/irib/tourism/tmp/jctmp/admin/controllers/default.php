<?php
/**
* @version		$Id: #name#.php 183 2014-02-17 16:17:50Z michel $
* @package		Contacts
* @subpackage 	Controllers
* @copyright	Copyright (C) 2015, . All rights reserved.
* @license #
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * ContactsDefault Controller
 *
 * @package    Contacts
 * @subpackage Controllers
 */
class ContactsControllerDefault  extends JControllerAdmin
{
    // Your Code starts here
}
?>
