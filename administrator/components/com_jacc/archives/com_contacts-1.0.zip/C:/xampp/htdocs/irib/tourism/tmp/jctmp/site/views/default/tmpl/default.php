<?php
/**
 * @version		$Id: default.php 183 2014-02-17 16:17:50Z michel $
 * @copyright	Copyright (C) 2015, . All rights reserved.
 * @license 
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div class="contentpane">
	<div><h4>Some interesting informations</h4></div>
	Default
</div>
