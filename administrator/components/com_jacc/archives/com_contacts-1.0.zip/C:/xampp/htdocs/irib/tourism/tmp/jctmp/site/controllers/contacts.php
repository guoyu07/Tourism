 <?php
/**
* @version		$Id$ $Revision$ $Date$ $Author$ $
* @package		Contacts
* @subpackage 	Controllers
* @copyright	Copyright (C) 2015, . All rights reserved.
* @license 		
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * Contactscontacts Controller
 *
 * @package    Contacts
 * @subpackage Controllers
 */
class ContactsControllercontacts extends JControllerLegacy
{
		
}// class
?> 