CREATE TABLE IF NOT EXISTS `#__contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` tinytext,
  `created` datetime DEFAULT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `published` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

