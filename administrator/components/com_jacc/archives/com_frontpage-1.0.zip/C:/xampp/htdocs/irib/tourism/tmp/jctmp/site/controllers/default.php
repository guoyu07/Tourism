<?php
/**
 * @version		$Id: #name#.php 183 2014-02-17 16:17:50Z michel $
 * @package		Frontpage
 * @subpackage 	Controllers
 * @copyright	Copyright (C) 2015, . All rights reserved.
 * @license #
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * FrontpageDefault Controller
 *
 * @package    Frontpage
 * @subpackage Controllers
 */
class FrontpageControllerDefault  extends JControllerLegacy
{
    // Your Code starts here
}
?>
