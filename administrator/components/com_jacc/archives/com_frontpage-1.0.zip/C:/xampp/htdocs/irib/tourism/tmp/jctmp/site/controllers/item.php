 <?php
/**
* @version		$Id$ $Revision$ $Date$ $Author$ $
* @package		Frontpage
* @subpackage 	Controllers
* @copyright	Copyright (C) 2015, . All rights reserved.
* @license #
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * FrontpageItem Controller
 *
 * @package    Frontpage
 * @subpackage Controllers
 */
class FrontpageControllerItem extends JControllerLegacy
{
		
}// class
?>