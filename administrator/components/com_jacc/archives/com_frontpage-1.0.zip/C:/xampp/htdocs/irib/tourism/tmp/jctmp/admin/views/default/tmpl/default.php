<?php
/**
 * @version		$Id: default.php 147 2013-10-06 08:58:34Z michel $
 * @copyright	Copyright (C) 2015, . All rights reserved.
 * @license #
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div class="contentpane">
	<div><h4>Some interesting informations</h4></div>
	Default
</div>
