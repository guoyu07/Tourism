K2 v3 Development Build
===============

This is the code repo for K2 v3 (Development Build). Please do not use this build of K2 on production websites.

Once the code is considered stable to be released as v3.0.0, it will be moved over to the main K2 repo at: https://github.com/joomlaworks/k2

To report bugs or other issues or even small feature additions or feature improvements, please use this repo's issue tracker: https://github.com/joomlaworks/k2-v3-dev-build/issues
